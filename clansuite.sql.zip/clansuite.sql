-- phpMyAdmin SQL Dump
-- version 2.6.4-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Erstellungszeit: 19. Mai 2006 um 23:27
-- Server Version: 4.1.14
-- PHP-Version: 5.0.5
-- 
-- Datenbank: `clansuite`
-- 

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_adminmenu`
-- 

CREATE TABLE `suite_adminmenu` (
  `id` tinyint(3) unsigned NOT NULL default '0',
  `parent` tinyint(3) unsigned NOT NULL default '0',
  `type` varchar(255) collate latin1_german1_ci NOT NULL default '',
  `text` varchar(255) collate latin1_german1_ci NOT NULL default '',
  `href` varchar(255) collate latin1_german1_ci NOT NULL default '',
  `title` varchar(255) collate latin1_german1_ci NOT NULL default '',
  `target` varchar(255) collate latin1_german1_ci NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

-- 
-- Daten für Tabelle `suite_adminmenu`
-- 

INSERT INTO `suite_adminmenu` (`id`, `parent`, `type`, `text`, `href`, `title`, `target`) VALUES (4, 0, 'button', 'System', 'null', 'System', '_self'),
(3, 0, 'button', 'Categories', 'admin/categories/index.php', 'Categories', '_self'),
(6, 0, 'button', 'Hilfe', 'null', 'Hilfe', '_self'),
(1, 0, 'button', 'Home', 'index.php', 'Home', '_self'),
(2, 0, 'button', 'Module', 'admin/module/index.php', 'Module', '_self'),
(7, 6, 'item', 'Hilfe', 'help.php', 'Hilfe', '_self'),
(8, 6, 'item', 'Handbuch', 'manual.php', 'Handbuch', '_self'),
(5, 0, 'button', 'Users', 'admin/users/index.php', 'Users', '_self'),
(9, 6, 'item', 'Report Bug & Give Feedback', 'bugreport.php', 'Report Bug & Give Feedback', '_self'),
(10, 6, 'item', 'Über Clansuite', 'about.php', 'Über Clansuite', '_self'),
(11, 10, 'item', 'unter Clansuitel', 'test.php', 'unter Clansuite', '_self'),
(12, 6, 'item', 'test', 'null', 'test', '_self'),
(13, 4, 'item', 'Menüeditor', 'admin/menueditor.php', 'Menüeditor', '_self'),
(14, 4, 'item', 'Templateeditor', 'admin/templateeditor.php', 'TemplateEditor', '_self');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_awards`
-- 

CREATE TABLE `suite_awards` (
  `awards_id` int(10) unsigned NOT NULL auto_increment,
  `awards_info` text character set latin1 collate latin1_german1_ci,
  `awards_event` int(10) unsigned default NULL,
  `awards_date` int(10) unsigned default NULL,
  `games_id` int(10) unsigned default NULL,
  `awards_rank` tinyint(3) unsigned default NULL,
  `squad_id` tinyint(3) default NULL,
  `user_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`awards_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Daten für Tabelle `suite_awards`
-- 

INSERT INTO `suite_awards` (`awards_id`, `awards_info`, `awards_event`, `awards_date`, `games_id`, `awards_rank`, `squad_id`, `user_id`) VALUES (1, 'Sunxplosion die huinderste\0', 1, NULL, 1, 1, NULL, 1);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_category`
-- 

CREATE TABLE `suite_category` (
  `cat_id` tinyint(4) NOT NULL auto_increment,
  `cat_modulname` text,
  `cat_sortorder` tinyint(4) default NULL,
  `cat_name` text,
  `cat_image_url` varchar(60) default NULL,
  `cat_description` varchar(90) default '0',
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

-- 
-- Daten für Tabelle `suite_category`
-- 

INSERT INTO `suite_category` (`cat_id`, `cat_modulname`, `cat_sortorder`, `cat_name`, `cat_image_url`, `cat_description`) VALUES (1, 'newso', NULL, 'keine', '', 'Diese News sind keiner Kategorie zugeordnet'),
(2, 'news', NULL, 'Allgemein', '/images/allgemein.gif', 'Allgemein'),
(3, 'news', NULL, 'Member', '/images/news/member.gif', 'Alles zum Thema Member'),
(4, 'news', NULL, 'Page', '/images/news/page.gif', 'Alles zum Thema Page'),
(5, 'news', NULL, 'IRC', '/images/news/irc.gif', 'Alles was zum Thema IRC geh?rt'),
(6, 'news', NULL, 'Clan-Wars', '/images/news/clanwars.gif', 'Alles zum Thema Clan-Wars'),
(7, 'news', NULL, 'Sonstiges', '/images/news/sonstiges.gif', 'alles'),
(8, 'news', NULL, 'LAN', '', 'lan'),
(10, '/design', NULL, 'good night', NULL, '0');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_games`
-- 

CREATE TABLE `suite_games` (
  `games_id` tinyint(4) unsigned NOT NULL auto_increment,
  `name` varchar(45) collate latin1_german1_ci default NULL,
  `url` varchar(240) collate latin1_german1_ci default NULL,
  `sortorder` int(4) unsigned default NULL,
  `leader` int(10) unsigned default NULL,
  `image_url` varchar(220) collate latin1_german1_ci default NULL,
  PRIMARY KEY  (`games_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=1 ;

-- 
-- Daten für Tabelle `suite_games`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_group_rights`
-- 

CREATE TABLE `suite_group_rights` (
  `group_id` int(5) unsigned zerofill NOT NULL default '00000',
  `right_id` int(5) unsigned zerofill NOT NULL default '00000',
  `right_pos` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`group_id`,`right_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten für Tabelle `suite_group_rights`
-- 

INSERT INTO `suite_group_rights` (`group_id`, `right_id`, `right_pos`) VALUES (00001, 00001, 1),
(00002, 00002, 1);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_groups`
-- 

CREATE TABLE `suite_groups` (
  `group_id` int(5) unsigned NOT NULL auto_increment,
  `group_pos` tinyint(4) unsigned NOT NULL default '1',
  `group_name` varchar(75) character set latin1 collate latin1_german1_ci default NULL,
  PRIMARY KEY  (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Daten für Tabelle `suite_groups`
-- 

INSERT INTO `suite_groups` (`group_id`, `group_pos`, `group_name`) VALUES (1, 1, 'Administrator'),
(2, 2, 'Newsgruppe'),
(3, 3, 'Gästebuchgruppe');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_guestbook`
-- 

CREATE TABLE `suite_guestbook` (
  `gbook_id` int(8) unsigned NOT NULL auto_increment,
  `users_id` int(11) NOT NULL default '0',
  `gbook_time_added` datetime default '0000-00-00 00:00:00',
  `gbook_nick` varchar(20) collate latin1_german1_ci NOT NULL default '',
  `gbook_email` varchar(30) collate latin1_german1_ci NOT NULL default '',
  `gbook_icq` varchar(12) collate latin1_german1_ci NOT NULL default '',
  `gbook_website` varchar(30) collate latin1_german1_ci NOT NULL default '',
  `gbook_town` varchar(15) collate latin1_german1_ci NOT NULL default '',
  `gbook_text` text collate latin1_german1_ci NOT NULL,
  `gbook_ip` varchar(15) collate latin1_german1_ci NOT NULL default '',
  PRIMARY KEY  (`gbook_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=8 ;

-- 
-- Daten für Tabelle `suite_guestbook`
-- 

INSERT INTO `suite_guestbook` (`gbook_id`, `users_id`, `gbook_time_added`, `gbook_nick`, `gbook_email`, `gbook_icq`, `gbook_website`, `gbook_town`, `gbook_text`, `gbook_ip`) VALUES (1, 1, '2005-07-29 02:35:25', 'nick', 'email', 'icq', 'website', 'town', 'text', '1'),
(2, 0, '2005-08-15 21:25:43', 'test', 'test@test.com', '3214', '4123', '423123', '4234234', '1');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_guestbook_comments`
-- 

CREATE TABLE `suite_guestbook_comments` (
  `gbook_id` int(8) unsigned NOT NULL default '0',
  `comment_id` int(10) unsigned NOT NULL default '0',
  `user_id` int(11) unsigned NOT NULL default '0',
  `body` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `pseudo` varchar(25) default NULL,
  `ip` varchar(15) NOT NULL default '',
  `host` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten für Tabelle `suite_guestbook_comments`
-- 

INSERT INTO `suite_guestbook_comments` (`gbook_id`, `comment_id`, `user_id`, `body`, `added`, `pseudo`, `ip`, `host`) VALUES (0, 1, 0, 'comment on guestbook', '2005-07-29 12:37:03', 'pseudo1', '127.0.0.1', 'localhost'),
(0, 2, 1, 'comment', '2005-07-29 12:37:13', NULL, '127.0.0.1', 'localhost'),
(0, 1, 0, '123', '2005-07-29 21:18:14', 'pseudo2', '127.0.0.1', 'localhost');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_log_sitestats`
-- 

CREATE TABLE `suite_log_sitestats` (
  `id` tinyint(4) NOT NULL auto_increment,
  `hits_total` int(11) default NULL,
  `visitors_total` int(11) default NULL,
  `hits_today` int(11) default NULL,
  `visitors_today` int(11) default NULL,
  `visitors_yesterday` int(11) default NULL,
  `max_visitors_day` int(11) default NULL,
  `max_visitors_online` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Daten für Tabelle `suite_log_sitestats`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_module`
-- 

CREATE TABLE `suite_module` (
  `modul_id` int(10) unsigned NOT NULL auto_increment,
  `m_name` varchar(175) collate latin1_german1_ci default NULL,
  `m_info` varchar(225) collate latin1_german1_ci default NULL,
  `m_url` varchar(255) collate latin1_german1_ci default NULL,
  `m_enabled` int(2) unsigned default NULL,
  `m_image_url` varchar(225) collate latin1_german1_ci default NULL,
  PRIMARY KEY  (`modul_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=144 ;

-- 
-- Daten für Tabelle `suite_module`
-- 

INSERT INTO `suite_module` (`modul_id`, `m_name`, `m_info`, `m_url`, `m_enabled`, `m_image_url`) VALUES (115, NULL, NULL, NULL, NULL, NULL),
(116, NULL, NULL, NULL, NULL, NULL),
(117, 'Guestbook', NULL, NULL, NULL, NULL),
(118, NULL, NULL, NULL, NULL, NULL),
(119, NULL, NULL, NULL, NULL, NULL),
(120, 'Guestbook', NULL, NULL, NULL, NULL),
(121, NULL, NULL, NULL, NULL, NULL),
(122, NULL, NULL, NULL, NULL, NULL),
(123, 'Guestbook', NULL, NULL, NULL, NULL),
(124, NULL, NULL, NULL, NULL, NULL),
(125, NULL, NULL, NULL, NULL, NULL),
(126, 'Guestbook', NULL, NULL, NULL, NULL),
(127, NULL, NULL, NULL, NULL, NULL),
(128, NULL, NULL, NULL, NULL, NULL),
(129, 'Guestbook', NULL, NULL, NULL, NULL),
(130, NULL, NULL, NULL, NULL, NULL),
(131, NULL, NULL, NULL, NULL, NULL),
(132, 'Guestbook', NULL, NULL, NULL, NULL),
(133, NULL, NULL, NULL, NULL, NULL),
(134, NULL, NULL, NULL, NULL, NULL),
(135, 'Guestbook', NULL, NULL, NULL, NULL),
(136, 'Guestbook', NULL, NULL, NULL, NULL),
(137, 'News', NULL, NULL, NULL, NULL),
(138, 'Guestbook', NULL, NULL, NULL, NULL),
(139, 'News', NULL, NULL, NULL, NULL),
(140, 'Guestbook', NULL, NULL, NULL, NULL),
(141, 'News', NULL, NULL, NULL, NULL),
(142, 'Guestbook', NULL, NULL, NULL, NULL),
(143, 'News', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_news`
-- 

CREATE TABLE `suite_news` (
  `news_id` int(11) NOT NULL auto_increment,
  `news_title` varchar(255) NOT NULL default '',
  `news_body` text NOT NULL,
  `news_category` tinyint(4) NOT NULL default '0',
  `user_id` int(11) unsigned NOT NULL default '0',
  `news_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `news_hidden` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`news_id`,`news_category`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

-- 
-- Daten für Tabelle `suite_news`
-- 

INSERT INTO `suite_news` (`news_id`, `news_title`, `news_body`, `news_category`, `user_id`, `news_added`, `news_hidden`) VALUES (14, '123123', '1231231', 2, 1, '2005-08-09 13:48:48', 0);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_news_comments`
-- 

CREATE TABLE `suite_news_comments` (
  `news_id` int(11) NOT NULL default '0',
  `comment_id` int(10) unsigned NOT NULL default '0',
  `user_id` int(11) unsigned NOT NULL default '0',
  `body` text NOT NULL,
  `added` datetime NOT NULL default '0000-00-00 00:00:00',
  `pseudo` varchar(25) default NULL,
  `ip` varchar(15) NOT NULL default '',
  `host` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten für Tabelle `suite_news_comments`
-- 

INSERT INTO `suite_news_comments` (`news_id`, `comment_id`, `user_id`, `body`, `added`, `pseudo`, `ip`, `host`) VALUES (6, 1, 1, '123', '2005-07-29 13:04:07', '', '127.0.0.1', 'localhost'),
(6, 2, 0, '1234567', '2005-07-29 16:50:08', 'blub', '127.0.0.1', 'localhost'),
(14, 0, 0, 'testeee', '2006-03-04 02:25:42', 'test', '127.0.0.1', 'localhost'),
(14, 0, 0, 'eee', '2006-03-04 02:25:57', 'tester', '127.0.0.1', 'localhost'),
(14, 0, 1, '[center]test[/center]', '2006-05-11 18:30:57', 'test', '127.0.0.1', 'localhost');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_rights`
-- 

CREATE TABLE `suite_rights` (
  `right_id` int(11) unsigned NOT NULL default '0',
  `right_name` varchar(150) character set latin1 collate latin1_german1_ci NOT NULL default '',
  PRIMARY KEY  (`right_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten für Tabelle `suite_rights`
-- 

INSERT INTO `suite_rights` (`right_id`, `right_name`) VALUES (1, 'Systemrecht'),
(2, 'Newsrecht'),
(3, 'Userrecht');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_servers`
-- 

CREATE TABLE `suite_servers` (
  `server_id` tinyint(4) unsigned NOT NULL auto_increment,
  `server_name` varchar(120) collate latin1_german1_ci default NULL,
  `server_ip` int(16) unsigned default NULL,
  `server_port` int(5) unsigned default NULL,
  `game_id` tinyint(4) unsigned default NULL,
  PRIMARY KEY  (`server_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=1 ;

-- 
-- Daten für Tabelle `suite_servers`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_session`
-- 

CREATE TABLE `suite_session` (
  `SessionData` text NOT NULL,
  `SessionName` text character set latin1 collate latin1_german1_ci NOT NULL,
  `SessionId` varchar(255) character set latin1 collate latin1_german1_ci NOT NULL default '',
  `SessionExpire` int(11) NOT NULL default '0',
  `SessionVisibility` tinyint(4) NOT NULL default '0',
  `SessionWhere` text character set latin1 NOT NULL,
  `user_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`SessionId`),
  KEY `user_id` (`user_id`),
  KEY `session_id` (`SessionId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Daten für Tabelle `suite_session`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_settings`
-- 

CREATE TABLE `suite_settings` (
  `modulname` text collate latin1_german1_ci NOT NULL,
  `variable` tinytext character set latin1 collate latin1_general_ci,
  `data` text character set latin1 collate latin1_general_ci
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;

-- 
-- Daten für Tabelle `suite_settings`
-- 

INSERT INTO `suite_settings` (`modulname`, `variable`, `data`) VALUES ('clansuite', 'version', '0.1-alpha');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_squads`
-- 

CREATE TABLE `suite_squads` (
  `squad_id` int(10) unsigned NOT NULL auto_increment,
  `games_id` tinyint(4) unsigned NOT NULL default '0',
  `squad_name` varchar(45) collate latin1_german1_ci default NULL,
  `squad_info` varchar(175) collate latin1_german1_ci default NULL,
  `squad_sortorder` int(2) unsigned default NULL,
  PRIMARY KEY  (`squad_id`,`games_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=1 ;

-- 
-- Daten für Tabelle `suite_squads`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_stats`
-- 

CREATE TABLE `suite_stats` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` varchar(20) NOT NULL default '',
  `ip` varchar(15) NOT NULL default '',
  `host` varchar(100) NOT NULL default '',
  `browser` varchar(50) NOT NULL default '',
  `os` varchar(50) NOT NULL default '',
  `referer` varchar(200) NOT NULL default '',
  `day` int(2) NOT NULL default '0',
  `month` int(2) NOT NULL default '0',
  `year` int(4) NOT NULL default '0',
  `hour` int(2) NOT NULL default '0',
  `date` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`),
  KEY `host` (`host`),
  KEY `browser` (`browser`),
  KEY `os` (`os`),
  KEY `referer` (`referer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Daten für Tabelle `suite_stats`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_user_groups`
-- 

CREATE TABLE `suite_user_groups` (
  `user_id` int(10) unsigned NOT NULL default '0',
  `group_id` int(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`user_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten für Tabelle `suite_user_groups`
-- 

INSERT INTO `suite_user_groups` (`user_id`, `group_id`) VALUES (1, 1),
(1, 2),
(2, 3);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_user_rights`
-- 

CREATE TABLE `suite_user_rights` (
  `user_id` int(10) unsigned NOT NULL default '0',
  `right_id` int(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`user_id`,`right_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Daten für Tabelle `suite_user_rights`
-- 

INSERT INTO `suite_user_rights` (`user_id`, `right_id`) VALUES (1, 1),
(1, 3),
(2, 2),
(2, 3);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `suite_users`
-- 

CREATE TABLE `suite_users` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `email` varchar(150) NOT NULL default '',
  `nick` varchar(25) NOT NULL default '',
  `password` varchar(32) NOT NULL default '',
  `new_password` varchar(32) default NULL,
  `level` tinyint(1) NOT NULL default '0',
  `joined` date default NULL,
  `timestamp` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `first_name` varchar(25) NOT NULL default '',
  `last_name` varchar(25) NOT NULL default '',
  `infotext` text NOT NULL,
  `disabled` tinyint(1) default NULL,
  PRIMARY KEY  (`user_id`),
  KEY `email` (`email`),
  KEY `nick` (`nick`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Daten für Tabelle `suite_users`
-- 

INSERT INTO `suite_users` (`user_id`, `email`, `nick`, `password`, `new_password`, `level`, `joined`, `timestamp`, `first_name`, `last_name`, `infotext`, `disabled`) VALUES (1, 'admin@localhost', 'admin', '21232f297a57a5a743894a0e4a801fc3', NULL, 100, '2005-07-28', '2006-05-19 19:35:26', 'john', 'vain', '', NULL),
(4, 'gast@localhost', 'gast', '21232f297a57a5a743894a0e4a801fc3', NULL, 0, '2006-04-11', '2006-05-19 23:24:35', 'gastvorname', 'gastnachname', '', NULL);
